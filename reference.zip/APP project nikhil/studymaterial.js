const subjects = [
  { name: "Mathematics", url: "materials/mathematics.html" },
  { name: "Physics", url: "materials/physics.html" },
  { name: "English", url: "materials/english.html" },
  { name: "Chemistry", url: "materials/chemistry.html" }
];

function renderSubjects() {
  const listDiv = document.getElementById('subjects-list');
  listDiv.innerHTML = '';
  subjects.forEach((subject) => {
    const card = document.createElement('div');
    card.classList.add('subject-card');
    card.textContent = subject.name;
    card.onclick = () => {
      window.location.href = subject.url;
    };
    listDiv.appendChild(card);
  });
}

renderSubjects();
