// Demo data -- replace with backend fetch later.
const students = [
  { name: 'Aryan Sharma', totalMarks: 286 },
  { name: 'Priya Verma', totalMarks: 273 },
  { name: 'Rehan Khan', totalMarks: 268 },
  { name: 'Meera Nair', totalMarks: 256 },
  { name: 'Rohan', totalMarks: 291 },
  { name: 'Tanya Joshi', totalMarks: 241 },
];

// Sort and assign ranks
students.sort((a, b) => b.totalMarks - a.totalMarks);
students.forEach((stu, idx) => stu.rank = idx + 1);

function renderTable(studentsArr) {
  let tableHtml = `
    <table class="rank-table">
      <thead>
        <tr>
          <th>Rank</th>
          <th>Name</th>
          <th>Total Marks(300)</th>
        </tr>
      </thead>
      <tbody>
  `;
  studentsArr.forEach(stu => {
    tableHtml += `
      <tr>
        <td>${stu.rank}</td>
        <td>${stu.name}</td>
        <td>${stu.totalMarks}</td>
      </tr>
    `;
  });
  tableHtml += '</tbody></table>';
  document.getElementById('rank-table-container').innerHTML = tableHtml;
}

function renderGraph(studentsArr) {
  const top = studentsArr.slice(0, 5);
  const ctx = document.getElementById('rankChart').getContext('2d');
  new Chart(ctx, {
    type: 'bar',
    data: {
      labels: top.map(s => s.name),
      datasets: [{
        label: 'Total Marks',
        data: top.map(s => s.totalMarks),
        backgroundColor: '#388fe7',
        borderRadius: 7,
      }]
    },
    options: {
      plugins: {
        legend: { display: false }
      },
      scales: {
        y: {
          beginAtZero: true,
          title: { display: true, text: 'Marks' }
        }
      }
    }
  });
}

renderTable(students);
renderGraph(students);
