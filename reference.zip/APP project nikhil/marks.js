const marksData = [
  {
    subject: "Mathematics",
    components: [
      { name: "Component 1", marksObtained: 12 },
      { name: "Component 2", marksObtained: 14 },
      { name: "Component 3", marksObtained: 11 },
      { name: "Component 4", marksObtained: 13 }
    ]
  },
  {
    subject: "Physics",
    components: [
      { name: "Component 1", marksObtained: 10 },
      { name: "Component 2", marksObtained: 8 },
      { name: "Component 3", marksObtained: 13 },
      { name: "Component 4", marksObtained: 14 }
    ]
  },
  {
    subject: "English",
    components: [
      { name: "Component 1", marksObtained: 15 },
      { name: "Component 2", marksObtained: 14 },
      { name: "Component 3", marksObtained: 15 },
      { name: "Component 4", marksObtained: 15 }
    ]
  }
];

const container = document.getElementById('container');

marksData.forEach((subjectData, index) => {
  // Section for subject
  const section = document.createElement('div');
  section.classList.add('subject-section');

  // Title
  const title = document.createElement('div');
  title.classList.add('subject-title');
  title.textContent = subjectData.subject;
  section.appendChild(title);

  // Canvas for chart
  const canvas = document.createElement('canvas');
  canvas.id = 'chart-' + index;
  section.appendChild(canvas);

  // Components cards
  const compsDiv = document.createElement('div');
  compsDiv.classList.add('components-list');
  subjectData.components.forEach(component => {
    const card = document.createElement('div');
    card.classList.add('component-card');
    card.innerHTML = `
      <div class="component-title">${component.name}</div>
      <div class="component-marks">${component.marksObtained} / 15</div>
    `;
    compsDiv.appendChild(card);
  });
  section.appendChild(compsDiv);
  container.appendChild(section);

  // Chart.js line chart
  const labels = subjectData.components.map(comp => comp.name);
  const dataPoints = subjectData.components.map(comp => comp.marksObtained);
  const maxMarks = 15;

  new Chart(canvas.getContext('2d'), {
    type: 'line',
    data: {
      labels: labels,
      datasets: [{
        label: 'Marks Obtained',
        data: dataPoints,
        fill: false,
        borderColor: '#348af7',
        backgroundColor: '#348af7',
        tension: 0.19,
        pointRadius: 6,
        pointHoverRadius: 8,
        borderWidth: 3
      }]
    },
    options: {
      responsive: true,
      scales: {
        y: {
          min: 0,
          max: maxMarks,
          ticks: { stepSize: 1 },
          title: {
            display: true,
            text: 'Marks (out of 15)'
          }
        }
      }
    }
  });
});
