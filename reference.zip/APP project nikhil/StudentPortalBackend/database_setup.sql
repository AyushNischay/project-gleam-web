-- Edumetrica Database Setup Script
-- Run this in your MySQL server to create the database and tables

CREATE DATABASE IF NOT EXISTS edumetrica_db;
USE edumetrica_db;

-- Create students table
CREATE TABLE IF NOT EXISTS students (
    student_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    password VARCHAR(255) NOT NULL,
    enrollment_date DATE NOT NULL
);

-- Create subjects table
CREATE TABLE IF NOT EXISTS subjects (
    subject_id INT PRIMARY KEY AUTO_INCREMENT,
    subject_name VARCHAR(100) NOT NULL,
    teacher_name VARCHAR(100) NOT NULL
);

-- Create attendance table
CREATE TABLE IF NOT EXISTS attendance (
    attendance_id INT PRIMARY KEY AUTO_INCREMENT,
    student_id INT NOT NULL,
    subject_id INT NOT NULL,
    total_classes INT NOT NULL DEFAULT 0,
    attended_classes INT NOT NULL DEFAULT 0,
    missed_classes INT NOT NULL DEFAULT 0,
    attendance_percentage DECIMAL(5,2) NOT NULL DEFAULT 0.00,
    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,
    FOREIGN KEY (subject_id) REFERENCES subjects(subject_id) ON DELETE CASCADE
);

-- Insert sample data
INSERT INTO students (name, email, password, enrollment_date) VALUES
('John Doe', 'john.doe@email.com', 'password123', '2024-01-15'),
('Jane Smith', 'jane.smith@email.com', 'password456', '2024-01-16'),
('Mike Johnson', 'mike.johnson@email.com', 'password789', '2024-01-17');

INSERT INTO subjects (subject_name, teacher_name) VALUES
('Mathematics', 'Dr. Anderson'),
('Physics', 'Prof. Wilson'),
('Chemistry', 'Dr. Davis'),
('Computer Science', 'Prof. Taylor');

INSERT INTO attendance (student_id, subject_id, total_classes, attended_classes, missed_classes, attendance_percentage) VALUES
(1, 1, 20, 18, 2, 90.00),
(1, 2, 18, 15, 3, 83.33),
(2, 1, 20, 19, 1, 95.00),
(2, 3, 15, 12, 3, 80.00),
(3, 2, 18, 16, 2, 88.89),
(3, 4, 22, 20, 2, 90.91);

-- Display setup completion
SELECT 'Database setup completed successfully!' AS status;