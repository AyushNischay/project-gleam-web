package com.app.backend.dao;

import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.sql.Timestamp;
import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

import com.app.backend.model.Attendance;

public class AttendanceDAO {
    private static final String SELECT_BASE = "SELECT attendance_id, student_id, subject_id, total_classes, attended_classes, missed_classes, attendance_percentage, last_updated FROM attendance";
    private static final String SELECT_BY_STUDENT = SELECT_BASE + " WHERE student_id = ?";
    private static final String INSERT = "INSERT INTO attendance(student_id, subject_id, total_classes, attended_classes, missed_classes, attendance_percentage, last_updated) VALUES (?,?,?,?,?,?,?)";

    public List<Attendance> getAllAttendance() {
        List<Attendance> list = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(SELECT_BASE);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(mapRow(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error fetching attendance: " + e.getMessage());
        }
        return list;
    }

    public List<Attendance> getAttendanceByStudentId(int studentId) {
        List<Attendance> list = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(SELECT_BY_STUDENT)) {
            ps.setInt(1, studentId);
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) {
                    list.add(mapRow(rs));
                }
            }
        } catch (SQLException e) {
            System.err.println("Error fetching attendance for student " + studentId + ": " + e.getMessage());
        }
        return list;
    }

    public boolean addAttendance(Attendance a) {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(INSERT, Statement.RETURN_GENERATED_KEYS)) {
            ps.setInt(1, a.getStudentId());
            ps.setInt(2, a.getSubjectId());
            ps.setInt(3, a.getTotalClasses());
            ps.setInt(4, a.getAttendedClasses());
            ps.setInt(5, a.getMissedClasses());
            ps.setBigDecimal(6, a.getAttendancePercentage());
            ps.setTimestamp(7, a.getLastUpdated() != null ? Timestamp.valueOf(a.getLastUpdated()) : Timestamp.valueOf(LocalDateTime.now()));
            int affected = ps.executeUpdate();
            if (affected == 1) {
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (keys.next()) {
                        a.setAttendanceId(keys.getInt(1));
                    }
                }
                return true;
            }
        } catch (SQLException e) {
            System.err.println("Error adding attendance: " + e.getMessage());
        }
        return false;
    }

    private Attendance mapRow(ResultSet rs) throws SQLException {
        int id = rs.getInt("attendance_id");
        int studentId = rs.getInt("student_id");
        int subjectId = rs.getInt("subject_id");
        int totalClasses = rs.getInt("total_classes");
        int attendedClasses = rs.getInt("attended_classes");
        int missedClasses = rs.getInt("missed_classes");
        BigDecimal percentage = rs.getBigDecimal("attendance_percentage");
        Timestamp ts = rs.getTimestamp("last_updated");
        LocalDateTime lastUpdated = ts != null ? ts.toLocalDateTime() : null;
        return new Attendance(id, studentId, subjectId, totalClasses, attendedClasses, missedClasses, percentage, lastUpdated);
    }
}
