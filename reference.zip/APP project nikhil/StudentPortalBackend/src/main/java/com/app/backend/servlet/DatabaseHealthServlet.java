package com.app.backend.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.DatabaseMetaData;
import java.sql.SQLException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.app.backend.dao.DBConnection;

@WebServlet(name = "DatabaseHealthServlet", urlPatterns = {"/health/db"})
public class DatabaseHealthServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json;charset=UTF-8");
        try (PrintWriter out = resp.getWriter()) {
            try (Connection conn = DBConnection.getConnection()) {
                if (conn != null && !conn.isClosed() && conn.isValid(5)) {
                    DatabaseMetaData meta = conn.getMetaData();
                    out.printf("{\"status\":\"UP\",\"database\":\"%s\",\"version\":\"%s\",\"driver\":\"%s\",\"url\":\"%s\"}", 
                              meta.getDatabaseProductName(),
                              meta.getDatabaseProductVersion(),
                              meta.getDriverName(),
                              meta.getURL());
                } else {
                    resp.setStatus(500);
                    out.print("{\"status\":\"DOWN\",\"error\":\"Connection is null, closed, or invalid\"}");
                }
            } catch (SQLException e) {
                resp.setStatus(500);
                out.printf("{\"status\":\"DOWN\",\"error\":\"%s\"}", escape(e.getMessage()));
            }
        }
    }

    private String escape(String s) { 
        if (s == null) return "";
        return s.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", "\\n").replace("\r", "\\r");
    }
}
