package com.app.backend;
import java.util.List;

import com.app.backend.dao.DBConnection;
import com.app.backend.dao.StudentDAO;
import com.app.backend.model.Student;

public class MainTest {
    public static void main(String[] args) {
        System.out.println("=== Database Connection Test ===");
        
        // Test connection first
        if (DBConnection.testConnection()) {
            System.out.println("✓ Database connection successful!");
        } else {
            System.out.println("✗ Database connection failed!");
            return;
        }
        
        System.out.println("\n=== Fetching Students ===");
        StudentDAO dao = new StudentDAO();
        List<Student> students = dao.getAllStudents();
        if (students.isEmpty()) {
            System.out.println("No students found in database.");
        } else {
            System.out.println("Found " + students.size() + " student(s):");
            students.forEach(System.out::println);
        }
    }
}