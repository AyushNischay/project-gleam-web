package com.app.backend.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDateTime;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import com.app.backend.dao.AttendanceDAO;
import com.app.backend.dao.StudentDAO;
import com.app.backend.dao.SubjectDAO;
import com.app.backend.model.Attendance;

@WebServlet(name = "AttendanceDataServlet", urlPatterns = {"/api/attendance"})
public class AttendanceDataServlet extends HttpServlet {
    
    private AttendanceDAO attendanceDAO = new AttendanceDAO();
    private StudentDAO studentDAO = new StudentDAO();
    private SubjectDAO subjectDAO = new SubjectDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json;charset=UTF-8");
        resp.setHeader("Access-Control-Allow-Origin", "*");
        
        String studentIdStr = req.getParameter("studentId");
        
        try (PrintWriter out = resp.getWriter()) {
            if (studentIdStr != null) {
                // Get attendance for specific student
                int studentId = Integer.parseInt(studentIdStr);
                var attendanceList = attendanceDAO.getAttendanceByStudentId(studentId);
                
                JSONObject response = new JSONObject();
                response.put("success", true);
                response.put("attendance", attendanceList.stream()
                    .map(a -> new JSONObject()
                        .put("attendanceId", a.getAttendanceId())
                        .put("studentId", a.getStudentId())
                        .put("subjectId", a.getSubjectId())
                        .put("totalClasses", a.getTotalClasses())
                        .put("attendedClasses", a.getAttendedClasses())
                        .put("missedClasses", a.getMissedClasses())
                        .put("attendancePercentage", a.getAttendancePercentage())
                        .put("lastUpdated", a.getLastUpdated().toString()))
                    .toArray());
                out.print(response.toString());
            } else {
                // Get all attendance records
                var attendanceList = attendanceDAO.getAllAttendance();
                JSONObject response = new JSONObject();
                response.put("success", true);
                response.put("attendance", attendanceList.stream()
                    .map(a -> new JSONObject()
                        .put("attendanceId", a.getAttendanceId())
                        .put("studentId", a.getStudentId())
                        .put("subjectId", a.getSubjectId())
                        .put("totalClasses", a.getTotalClasses())
                        .put("attendedClasses", a.getAttendedClasses())
                        .put("missedClasses", a.getMissedClasses())
                        .put("attendancePercentage", a.getAttendancePercentage())
                        .put("lastUpdated", a.getLastUpdated().toString()))
                    .toArray());
                out.print(response.toString());
            }
        } catch (NumberFormatException e) {
            resp.setStatus(400);
            sendErrorResponse(resp, "Invalid student ID format");
        } catch (Exception e) {
            resp.setStatus(500);
            sendErrorResponse(resp, "Failed to fetch attendance: " + e.getMessage());
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json;charset=UTF-8");
        resp.setHeader("Access-Control-Allow-Origin", "*");
        
        try {
            String studentIdStr = req.getParameter("studentId");
            String subjectIdStr = req.getParameter("subjectId");
            String totalClassesStr = req.getParameter("totalClasses");
            String attendedClassesStr = req.getParameter("attendedClasses");
            
            // Validate required fields
            if (studentIdStr == null || subjectIdStr == null || 
                totalClassesStr == null || attendedClassesStr == null) {
                resp.setStatus(400);
                sendErrorResponse(resp, "studentId, subjectId, totalClasses, and attendedClasses are required");
                return;
            }
            
            int studentId = Integer.parseInt(studentIdStr);
            int subjectId = Integer.parseInt(subjectIdStr);
            int totalClasses = Integer.parseInt(totalClassesStr);
            int attendedClasses = Integer.parseInt(attendedClassesStr);
            
            // Validate data
            if (totalClasses <= 0 || attendedClasses < 0 || attendedClasses > totalClasses) {
                resp.setStatus(400);
                sendErrorResponse(resp, "Invalid class numbers: attended classes cannot exceed total classes");
                return;
            }
            
            // Verify student and subject exist
            if (studentDAO.getStudentById(studentId) == null) {
                resp.setStatus(400);
                sendErrorResponse(resp, "Student not found");
                return;
            }
            
            if (subjectDAO.getSubjectById(subjectId) == null) {
                resp.setStatus(400);
                sendErrorResponse(resp, "Subject not found");
                return;
            }
            
            // Calculate values
            int missedClasses = totalClasses - attendedClasses;
            BigDecimal percentage = BigDecimal.valueOf((double) attendedClasses / totalClasses * 100)
                                              .setScale(2, RoundingMode.HALF_UP);
            
            // Create and save attendance
            Attendance attendance = new Attendance(studentId, subjectId, totalClasses, 
                                                 attendedClasses, missedClasses, percentage, LocalDateTime.now());
            boolean success = attendanceDAO.addAttendance(attendance);
            
            if (success) {
                JSONObject response = new JSONObject();
                response.put("success", true);
                response.put("message", "Attendance record added successfully");
                response.put("attendanceId", attendance.getAttendanceId());
                response.put("attendancePercentage", percentage);
                try (PrintWriter out = resp.getWriter()) {
                    out.print(response.toString());
                }
            } else {
                resp.setStatus(500);
                sendErrorResponse(resp, "Failed to add attendance record to database");
            }
            
        } catch (NumberFormatException e) {
            resp.setStatus(400);
            sendErrorResponse(resp, "Invalid number format in request parameters");
        } catch (Exception e) {
            resp.setStatus(500);
            sendErrorResponse(resp, "Error processing request: " + e.getMessage());
        }
    }

    @Override
    protected void doOptions(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setHeader("Access-Control-Allow-Origin", "*");
        resp.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
        resp.setHeader("Access-Control-Allow-Headers", "Content-Type");
        resp.setStatus(200);
    }
    
    private void sendErrorResponse(HttpServletResponse resp, String message) throws IOException {
        JSONObject error = new JSONObject();
        error.put("success", false);
        error.put("error", message);
        try (PrintWriter out = resp.getWriter()) {
            out.print(error.toString());
        }
    }
}