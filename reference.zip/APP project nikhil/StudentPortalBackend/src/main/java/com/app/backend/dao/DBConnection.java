package com.app.backend.dao;

import java.io.IOException;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

public final class DBConnection {
    private static final String PROPERTIES_FILE = "/db.properties"; // on classpath
    private static String url;
    private static String user;
    private static String password;

    static {
        loadProperties();
        loadDriver();
    }

    private DBConnection() {}

    private static void loadProperties() {
        Properties props = new Properties();
        try (InputStream in = DBConnection.class.getResourceAsStream(PROPERTIES_FILE)) {
            if (in == null) {
                throw new IllegalStateException("db.properties not found in classpath");
            }
            props.load(in);
            url = props.getProperty("db.url").trim();
            user = props.getProperty("db.user").trim();
            password = props.getProperty("db.password", "").trim();
        } catch (IOException e) {
            throw new ExceptionInInitializerError("Failed loading DB properties: " + e.getMessage());
        }
    }

    private static void loadDriver() {
        try {
            // Modern MySQL driver auto-registers, explicit load optional
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new ExceptionInInitializerError("MySQL Driver not found: " + e.getMessage());
        }
    }

    public static Connection getConnection() throws SQLException {
        Connection conn = DriverManager.getConnection(url, user, password);
        // Validate connection is working
        if (conn != null && !conn.isClosed() && conn.isValid(5)) {
            return conn;
        } else {
            throw new SQLException("Failed to establish valid database connection");
        }
    }

    // Method to test connection without throwing exceptions
    public static boolean testConnection() {
        try (Connection conn = getConnection()) {
            return conn != null && !conn.isClosed() && conn.isValid(5);
        } catch (SQLException e) {
            System.err.println("Connection test failed: " + e.getMessage());
            return false;
        }
    }
}
