package com.app.backend.model;

import java.math.BigDecimal;
import java.time.LocalDateTime;

public class Attendance {
    private int attendanceId;
    private int studentId;
    private int subjectId;
    private int totalClasses;
    private int attendedClasses;
    private int missedClasses;
    private BigDecimal attendancePercentage; // DECIMAL in DB
    private LocalDateTime lastUpdated;

    public Attendance() {}

    public Attendance(int attendanceId, int studentId, int subjectId, int totalClasses, int attendedClasses,
                      int missedClasses, BigDecimal attendancePercentage, LocalDateTime lastUpdated) {
        this.attendanceId = attendanceId;
        this.studentId = studentId;
        this.subjectId = subjectId;
        this.totalClasses = totalClasses;
        this.attendedClasses = attendedClasses;
        this.missedClasses = missedClasses;
        this.attendancePercentage = attendancePercentage;
        this.lastUpdated = lastUpdated;
    }

    public Attendance(int studentId, int subjectId, int totalClasses, int attendedClasses, int missedClasses,
                      BigDecimal attendancePercentage, LocalDateTime lastUpdated) {
        this.studentId = studentId;
        this.subjectId = subjectId;
        this.totalClasses = totalClasses;
        this.attendedClasses = attendedClasses;
        this.missedClasses = missedClasses;
        this.attendancePercentage = attendancePercentage;
        this.lastUpdated = lastUpdated;
    }

    public int getAttendanceId() { return attendanceId; }
    public void setAttendanceId(int attendanceId) { this.attendanceId = attendanceId; }
    public int getStudentId() { return studentId; }
    public void setStudentId(int studentId) { this.studentId = studentId; }
    public int getSubjectId() { return subjectId; }
    public void setSubjectId(int subjectId) { this.subjectId = subjectId; }
    public int getTotalClasses() { return totalClasses; }
    public void setTotalClasses(int totalClasses) { this.totalClasses = totalClasses; }
    public int getAttendedClasses() { return attendedClasses; }
    public void setAttendedClasses(int attendedClasses) { this.attendedClasses = attendedClasses; }
    public int getMissedClasses() { return missedClasses; }
    public void setMissedClasses(int missedClasses) { this.missedClasses = missedClasses; }
    public BigDecimal getAttendancePercentage() { return attendancePercentage; }
    public void setAttendancePercentage(BigDecimal attendancePercentage) { this.attendancePercentage = attendancePercentage; }
    public LocalDateTime getLastUpdated() { return lastUpdated; }
    public void setLastUpdated(LocalDateTime lastUpdated) { this.lastUpdated = lastUpdated; }

    @Override
    public String toString() {
        return "Attendance{" +
                "attendanceId=" + attendanceId +
                ", studentId=" + studentId +
                ", subjectId=" + subjectId +
                ", totalClasses=" + totalClasses +
                ", attendedClasses=" + attendedClasses +
                ", missedClasses=" + missedClasses +
                ", attendancePercentage=" + attendancePercentage +
                ", lastUpdated=" + lastUpdated +
                '}';
    }
}
