package com.app.backend;

import java.sql.Connection;
import java.sql.SQLException;
import java.sql.Statement;

import com.app.backend.dao.DBConnection;

public class DatabaseSetup {
    public static void main(String[] args) {
        System.out.println("=== Setting up Edumetrica Database ===");
        
        try {
            // First create the database by connecting to MySQL server directly
            createDatabase();
            
            // Then create tables and insert data
            setupTables();
            
            System.out.println("✅ Database setup completed successfully!");
            
        } catch (Exception e) {
            System.err.println("❌ Database setup failed: " + e.getMessage());
            e.printStackTrace();
        }
    }
    
    private static void createDatabase() throws SQLException {
        // Register MySQL driver first
        try {
            Class.forName("com.mysql.cj.jdbc.Driver");
        } catch (ClassNotFoundException e) {
            throw new SQLException("MySQL Driver not found: " + e.getMessage());
        }
        
        // Connect to MySQL server without specifying database
        String serverUrl = "jdbc:mysql://localhost:3306/?useSSL=false&allowPublicKeyRetrieval=true&serverTimezone=UTC";
        try (Connection conn = java.sql.DriverManager.getConnection(serverUrl, "root", "okok");
             Statement stmt = conn.createStatement()) {
            
            System.out.println("Creating database edumetrica_db...");
            stmt.executeUpdate("CREATE DATABASE IF NOT EXISTS edumetrica_db");
            System.out.println("✓ Database created successfully");
        }
    }
    
    private static void setupTables() throws SQLException {
        try (Connection conn = DBConnection.getConnection();
             Statement stmt = conn.createStatement()) {
            
            System.out.println("Creating tables...");
            
            // Create students table
            stmt.executeUpdate("""
                CREATE TABLE IF NOT EXISTS students (
                    student_id INT PRIMARY KEY AUTO_INCREMENT,
                    name VARCHAR(100) NOT NULL,
                    email VARCHAR(100) UNIQUE NOT NULL,
                    password VARCHAR(255) NOT NULL,
                    enrollment_date DATE NOT NULL
                )
                """);
            
            // Create subjects table
            stmt.executeUpdate("""
                CREATE TABLE IF NOT EXISTS subjects (
                    subject_id INT PRIMARY KEY AUTO_INCREMENT,
                    subject_name VARCHAR(100) NOT NULL,
                    teacher_name VARCHAR(100) NOT NULL
                )
                """);
            
            // Create attendance table
            stmt.executeUpdate("""
                CREATE TABLE IF NOT EXISTS attendance (
                    attendance_id INT PRIMARY KEY AUTO_INCREMENT,
                    student_id INT NOT NULL,
                    subject_id INT NOT NULL,
                    total_classes INT NOT NULL DEFAULT 0,
                    attended_classes INT NOT NULL DEFAULT 0,
                    missed_classes INT NOT NULL DEFAULT 0,
                    attendance_percentage DECIMAL(5,2) NOT NULL DEFAULT 0.00,
                    last_updated TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
                    FOREIGN KEY (student_id) REFERENCES students(student_id) ON DELETE CASCADE,
                    FOREIGN KEY (subject_id) REFERENCES subjects(subject_id) ON DELETE CASCADE
                )
                """);
            
            System.out.println("✓ Tables created successfully");
            
            // Insert sample data
            insertSampleData(stmt);
        }
    }
    
    private static void insertSampleData(Statement stmt) throws SQLException {
        System.out.println("Inserting sample data...");
        
        // Insert students
        stmt.executeUpdate("""
            INSERT IGNORE INTO students (name, email, password, enrollment_date) VALUES
            ('John Doe', 'john.doe@email.com', 'password123', '2024-01-15'),
            ('Jane Smith', 'jane.smith@email.com', 'password456', '2024-01-16'),
            ('Mike Johnson', 'mike.johnson@email.com', 'password789', '2024-01-17')
            """);
        
        // Insert subjects
        stmt.executeUpdate("""
            INSERT IGNORE INTO subjects (subject_name, teacher_name) VALUES
            ('Mathematics', 'Dr. Anderson'),
            ('Physics', 'Prof. Wilson'),
            ('Chemistry', 'Dr. Davis'),
            ('Computer Science', 'Prof. Taylor')
            """);
        
        // Insert attendance records
        stmt.executeUpdate("""
            INSERT IGNORE INTO attendance (student_id, subject_id, total_classes, attended_classes, missed_classes, attendance_percentage) VALUES
            (1, 1, 20, 18, 2, 90.00),
            (1, 2, 18, 15, 3, 83.33),
            (2, 1, 20, 19, 1, 95.00),
            (2, 3, 15, 12, 3, 80.00),
            (3, 2, 18, 16, 2, 88.89),
            (3, 4, 22, 20, 2, 90.91)
            """);
        
        System.out.println("✓ Sample data inserted successfully");
    }
}