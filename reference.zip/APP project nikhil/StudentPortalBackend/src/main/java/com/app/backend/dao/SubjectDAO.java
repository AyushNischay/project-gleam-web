package com.app.backend.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.app.backend.model.Subject;

public class SubjectDAO {
    private static final String SELECT_ALL = "SELECT subject_id, subject_name, teacher_name FROM subjects";
    private static final String SELECT_BY_ID = SELECT_ALL + " WHERE subject_id = ?";

    public List<Subject> getAllSubjects() {
        List<Subject> list = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(SELECT_ALL);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(mapRow(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error fetching subjects: " + e.getMessage());
        }
        return list;
    }

    public Subject getSubjectById(int id) {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(SELECT_BY_ID)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error fetching subject by id: " + e.getMessage());
        }
        return null;
    }

    private Subject mapRow(ResultSet rs) throws SQLException {
        int id = rs.getInt("subject_id");
        String name = rs.getString("subject_name");
        String teacher = rs.getString("teacher_name");
        return new Subject(id, name, teacher);
    }
}
