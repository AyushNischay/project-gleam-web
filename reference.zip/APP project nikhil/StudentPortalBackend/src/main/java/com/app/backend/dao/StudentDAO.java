package com.app.backend.dao;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;

import com.app.backend.model.Student;

public class StudentDAO {

    private static final String SELECT_ALL = "SELECT student_id, name, email, password, enrollment_date FROM students";
    private static final String SELECT_BY_ID = SELECT_ALL + " WHERE student_id = ?";
    private static final String INSERT = "INSERT INTO students(name, email, password, enrollment_date) VALUES (?,?,?,?)";

    public List<Student> getAllStudents() {
        List<Student> list = new ArrayList<>();
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(SELECT_ALL);
             ResultSet rs = ps.executeQuery()) {
            while (rs.next()) {
                list.add(mapRow(rs));
            }
        } catch (SQLException e) {
            System.err.println("Error fetching students: " + e.getMessage());
        }
        return list;
    }

    public Student getStudentById(int id) {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(SELECT_BY_ID)) {
            ps.setInt(1, id);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) {
                    return mapRow(rs);
                }
            }
        } catch (SQLException e) {
            System.err.println("Error fetching student by id: " + e.getMessage());
        }
        return null;
    }

    public boolean addStudent(Student s) {
        try (Connection conn = DBConnection.getConnection();
             PreparedStatement ps = conn.prepareStatement(INSERT, Statement.RETURN_GENERATED_KEYS)) {
            ps.setString(1, s.getName());
            ps.setString(2, s.getEmail());
            ps.setString(3, s.getPassword());
            ps.setDate(4, s.getEnrollmentDate() != null ? Date.valueOf(s.getEnrollmentDate()) : null);
            int affected = ps.executeUpdate();
            if (affected == 1) {
                try (ResultSet keys = ps.getGeneratedKeys()) {
                    if (keys.next()) {
                        s.setStudentId(keys.getInt(1));
                    }
                }
                return true;
            }
        } catch (SQLException e) {
            System.err.println("Error adding student: " + e.getMessage());
        }
        return false;
    }

    private Student mapRow(ResultSet rs) throws SQLException {
        int id = rs.getInt("student_id");
        String name = rs.getString("name");
        String email = rs.getString("email");
        String password = rs.getString("password");
        Date enrollDate = rs.getDate("enrollment_date");
        LocalDate localEnroll = enrollDate != null ? enrollDate.toLocalDate() : null;
        return new Student(id, name, email, password, localEnroll);
    }
}
