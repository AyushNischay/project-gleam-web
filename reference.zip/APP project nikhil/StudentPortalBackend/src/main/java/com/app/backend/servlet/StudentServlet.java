package com.app.backend.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.time.LocalDate;
import java.time.format.DateTimeParseException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.json.JSONObject;

import com.app.backend.dao.StudentDAO;
import com.app.backend.model.Student;

@WebServlet(name = "StudentServlet", urlPatterns = {"/api/students"})
public class StudentServlet extends HttpServlet {
    
    private StudentDAO studentDAO = new StudentDAO();

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json;charset=UTF-8");
        resp.setHeader("Access-Control-Allow-Origin", "*");
        
        try (PrintWriter out = resp.getWriter()) {
            var students = studentDAO.getAllStudents();
            JSONObject response = new JSONObject();
            response.put("success", true);
            response.put("students", students.stream()
                .map(s -> new JSONObject()
                    .put("id", s.getStudentId())
                    .put("name", s.getName())
                    .put("email", s.getEmail())
                    .put("enrollmentDate", s.getEnrollmentDate().toString()))
                .toArray());
            out.print(response.toString());
        } catch (Exception e) {
            resp.setStatus(500);
            sendErrorResponse(resp, "Failed to fetch students: " + e.getMessage());
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setContentType("application/json;charset=UTF-8");
        resp.setHeader("Access-Control-Allow-Origin", "*");
        
        try {
            String name = req.getParameter("name");
            String email = req.getParameter("email");
            String password = req.getParameter("password");
            String enrollmentDateStr = req.getParameter("enrollmentDate");
            
            // Validate required fields
            if (name == null || name.trim().isEmpty() ||
                email == null || email.trim().isEmpty() ||
                password == null || password.trim().isEmpty()) {
                resp.setStatus(400);
                sendErrorResponse(resp, "Name, email, and password are required");
                return;
            }
            
            // Parse enrollment date (default to today if not provided)
            LocalDate enrollmentDate = LocalDate.now();
            if (enrollmentDateStr != null && !enrollmentDateStr.trim().isEmpty()) {
                try {
                    enrollmentDate = LocalDate.parse(enrollmentDateStr);
                } catch (DateTimeParseException e) {
                    resp.setStatus(400);
                    sendErrorResponse(resp, "Invalid date format. Use YYYY-MM-DD");
                    return;
                }
            }
            
            // Create and save student
            Student student = new Student(name.trim(), email.trim(), password, enrollmentDate);
            boolean success = studentDAO.addStudent(student);
            
            if (success) {
                JSONObject response = new JSONObject();
                response.put("success", true);
                response.put("message", "Student added successfully");
                response.put("studentId", student.getStudentId());
                try (PrintWriter out = resp.getWriter()) {
                    out.print(response.toString());
                }
            } else {
                resp.setStatus(500);
                sendErrorResponse(resp, "Failed to add student to database");
            }
            
        } catch (Exception e) {
            resp.setStatus(500);
            sendErrorResponse(resp, "Error processing request: " + e.getMessage());
        }
    }

    @Override
    protected void doOptions(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
        resp.setHeader("Access-Control-Allow-Origin", "*");
        resp.setHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
        resp.setHeader("Access-Control-Allow-Headers", "Content-Type");
        resp.setStatus(200);
    }
    
    private void sendErrorResponse(HttpServletResponse resp, String message) throws IOException {
        JSONObject error = new JSONObject();
        error.put("success", false);
        error.put("error", message);
        try (PrintWriter out = resp.getWriter()) {
            out.print(error.toString());
        }
    }
}