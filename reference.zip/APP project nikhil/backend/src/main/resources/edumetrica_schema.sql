-- =========================================================
-- Edumetrica Database Initialization Script
-- Creates schema, tables, constraints, sample data
-- Engine: InnoDB, Charset: utf8mb4
-- =========================================================

-- 1. Create database (drop first if you want a clean slate)
-- DROP DATABASE IF EXISTS edumetrica_db;
CREATE DATABASE IF NOT EXISTS edumetrica_db
  CHARACTER SET utf8mb4
  COLLATE utf8mb4_unicode_ci;

USE edumetrica_db;

-- =========================================================
-- TABLE: students
-- Holds core student identity + enrollment metadata
-- Password field should store a bcrypt/argon2 hash in real usage
-- =========================================================
CREATE TABLE students (
    student_id       INT AUTO_INCREMENT PRIMARY KEY,
    name             VARCHAR(100)      NOT NULL,
    email            VARCHAR(100)      NOT NULL UNIQUE,
    password         VARCHAR(255)      NOT NULL,
    enrollment_date  DATE              NOT NULL,
    created_at       DATETIME          NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at       DATETIME          NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =========================================================
-- TABLE: subjects
-- Catalog of academic subjects with assigned teacher
-- =========================================================
CREATE TABLE subjects (
    subject_id    INT AUTO_INCREMENT PRIMARY KEY,
    subject_name  VARCHAR(100)  NOT NULL,
    teacher_name  VARCHAR(100)  NOT NULL,
    created_at    DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP,
    updated_at    DATETIME      NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT ux_subjects_name UNIQUE (subject_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =========================================================
-- TABLE: attendance
-- Stores per-student per-subject attendance aggregation.
-- Redundant columns (missed_classes, attendance_percentage) are stored
-- for fast dashboard reads. Triggers keep them consistent.
-- =========================================================
CREATE TABLE attendance (
    attendance_id          INT AUTO_INCREMENT PRIMARY KEY,
    student_id             INT            NOT NULL,
    subject_id             INT            NOT NULL,
    total_classes          INT            NOT NULL,
    attended_classes       INT            NOT NULL,
    missed_classes         INT            NOT NULL,
    attendance_percentage  DECIMAL(5,2)   NOT NULL,
    last_updated           DATETIME       NOT NULL DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    CONSTRAINT fk_attendance_student FOREIGN KEY (student_id)
        REFERENCES students(student_id) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT fk_attendance_subject FOREIGN KEY (subject_id)
        REFERENCES subjects(subject_id) ON UPDATE CASCADE ON DELETE CASCADE,
    CONSTRAINT ux_attendance_student_subject UNIQUE (student_id, subject_id),
    CONSTRAINT chk_total_nonnegative CHECK (total_classes >= 0),
    CONSTRAINT chk_attended_range CHECK (attended_classes >= 0 AND attended_classes <= total_classes)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

-- =========================================================
-- TRIGGERS: Keep missed_classes & attendance_percentage consistent
-- =========================================================
DELIMITER $$
CREATE TRIGGER trg_attendance_before_insert
BEFORE INSERT ON attendance
FOR EACH ROW
BEGIN
    SET NEW.missed_classes = (NEW.total_classes - NEW.attended_classes);
    IF NEW.total_classes = 0 THEN
        SET NEW.attendance_percentage = 0.00;
    ELSE
        SET NEW.attendance_percentage = ROUND((NEW.attended_classes / NEW.total_classes) * 100, 2);
    END IF;
END$$
CREATE TRIGGER trg_attendance_before_update
BEFORE UPDATE ON attendance
FOR EACH ROW
BEGIN
    SET NEW.missed_classes = (NEW.total_classes - NEW.attended_classes);
    IF NEW.total_classes = 0 THEN
        SET NEW.attendance_percentage = 0.00;
    ELSE
        SET NEW.attendance_percentage = ROUND((NEW.attended_classes / NEW.total_classes) * 100, 2);
    END IF;
END$$
DELIMITER ;

-- =========================================================
-- SAMPLE DATA
-- =========================================================
INSERT INTO students (name, email, password, enrollment_date) VALUES
  ('Rohan Verma',       'rohan@example.com',       'rohan123',        '2024-06-01'),
  ('Aryan Sharma',      'aryan.sharma@example.com','aryan123',        '2024-06-02'),
  ('Neha Patel',        'neha.patel@example.com',  'neha123',         '2024-06-03'),
  ('Sanya Kapoor',      'sanya.kapoor@example.com','sanya123',        '2024-06-04');

INSERT INTO subjects (subject_name, teacher_name) VALUES
  ('Mathematics', 'Prof. Mehta'),
  ('Physics',     'Dr. Rao'),
  ('Chemistry',   'Dr. Batra'),
  ('English',     'Ms. Dsouza');

-- Attendance seed data (triggers calculate missed & percentage)
INSERT INTO attendance (student_id, subject_id, total_classes, attended_classes, missed_classes, attendance_percentage, last_updated) VALUES
  (1, 1, 50, 46, 0, 0, NOW()),
  (1, 2, 40, 33, 0, 0, NOW()),
  (1, 3, 42, 39, 0, 0, NOW()),
  (1, 4, 38, 34, 0, 0, NOW()),
  (2, 1, 50, 44, 0, 0, NOW()),
  (2, 2, 40, 35, 0, 0, NOW()),
  (2, 3, 42, 37, 0, 0, NOW()),
  (2, 4, 38, 31, 0, 0, NOW()),
  (3, 1, 50, 48, 0, 0, NOW()),
  (3, 2, 40, 36, 0, 0, NOW()),
  (3, 3, 42, 40, 0, 0, NOW()),
  (3, 4, 38, 35, 0, 0, NOW()),
  (4, 1, 50, 41, 0, 0, NOW()),
  (4, 2, 40, 32, 0, 0, NOW()),
  (4, 3, 42, 34, 0, 0, NOW()),
  (4, 4, 38, 30, 0, 0, NOW());

-- Verification
SELECT * FROM attendance;
