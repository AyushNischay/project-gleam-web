// Dummy data for demo — replace with backend API fetch later
const attendanceData = [
  { subject: "Mathematics", totalClasses: 50, attended: 46, missed: 4, percentage: 92 },
  { subject: "Physics", totalClasses: 40, attended: 33, missed: 7, percentage: 82.5 },
  { subject: "English", totalClasses: 39, attended: 38, missed: 1, percentage: 97.4 },
  { subject: "Chemistry", totalClasses: 45, attended: 39, missed: 6, percentage: 86.7 }
];

function renderBars(data) {
  const area = document.getElementById('bars-area');
  area.innerHTML = '';
  data.forEach(item => {
    area.innerHTML += `
      <div class="subject-bar">
        <div class="title">${item.subject}</div>
        <div class="row-info">
          <div><b>Total:</b> ${item.totalClasses}</div>
          <div><b>Attended:</b> ${item.attended}</div>
          <div><b>Missed:</b> ${item.missed}</div>
        </div>
        <div class="att-bar-bg">
          <div class="att-bar-fill" style="width:${item.percentage}%"></div>
        </div>
        <div class="percent">Attendance: ${item.percentage.toFixed(1)}%</div>
      </div>
    `;
  });
}

// Initial render
renderBars(attendanceData);
